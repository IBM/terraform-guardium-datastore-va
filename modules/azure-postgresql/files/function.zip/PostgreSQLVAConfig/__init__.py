import os
import json
import logging
from datetime import datetime
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import psycopg2
from psycopg2 import sql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
KEY_VAULT_NAME = os.environ.get('KEY_VAULT_NAME')
SECRET_NAME = os.environ.get('SECRET_NAME')

# Required secret keys for validation
REQUIRED_SECRET_KEYS = [
    'sqlguard_username',
    'sqlguard_password',
    'endpoint',
    'port',
    'username',
    'password',
    'database'
]

def validate_secret_schema(secret):
    """Validate that the secret contains all required keys."""
    missing_keys = [key for key in REQUIRED_SECRET_KEYS if key not in secret]
    if missing_keys:
        error_msg = f"Secret validation failed. Missing required keys: {', '.join(missing_keys)}"
        logger.error(error_msg)
        raise ValueError(error_msg)
    try:
        int(secret['port'])
    except (ValueError, TypeError) as e:
        error_msg = f"Secret validation failed. 'port' must be a valid integer, got: {secret.get('port')}"
        logger.error(error_msg)
        raise ValueError(error_msg)
    logger.info("Secret schema validation passed")
    return True

def get_postgresql_credentials():
    """Retrieve PostgreSQL credentials from Azure Key Vault"""
    try:
        logger.info(f"Retrieving PostgreSQL credentials from Key Vault: {KEY_VAULT_NAME}")
        
        # Create Key Vault client using Managed Identity
        key_vault_uri = f"https://{KEY_VAULT_NAME}.vault.azure.net"
        credential = DefaultAzureCredential()
        client = SecretClient(vault_url=key_vault_uri, credential=credential)
        
        # Get the secret value
        logger.debug(f"Starting credential request from Key Vault: {SECRET_NAME}")
        secret = client.get_secret(SECRET_NAME)
        
        # Parse the secret JSON
        credentials = json.loads(secret.value)
        
        logger.debug(f"Completed credential request from Key Vault: {SECRET_NAME}")
        
        # Validate secret schema before proceeding
        validate_secret_schema(credentials)
        
        logger.info("Successfully retrieved and validated PostgreSQL credentials")
        
        return {
            'sqlguard_username': credentials['sqlguard_username'],
            'sqlguard_password': credentials['sqlguard_password'],
            'endpoint': credentials['endpoint'],
            'port': int(credentials['port']),
            'username': credentials['username'],
            'password': credentials['password'],
            'database': credentials['database']
        }
    except Exception as e:
        logger.error(f"Error retrieving PostgreSQL credentials: {e}")
        raise

def connect_to_postgresql(credentials):
    """Connect to PostgreSQL database with SSL"""
    try:
        logger.info(f"Connecting to PostgreSQL at {credentials['endpoint']}:{credentials['port']} as {credentials['username']} with SSL")
        
        conn = psycopg2.connect(
            host=credentials['endpoint'],
            port=credentials['port'],
            user=credentials['username'],
            password=credentials['password'],
            database=credentials['database'],
            sslmode='require'
        )
        
        # Verify SSL connection
        cursor = conn.cursor()
        cursor.execute("SELECT version()")
        version = cursor.fetchone()
        logger.info(f"Connected to PostgreSQL: {version[0]}")
        
        cursor.execute("SHOW ssl")
        ssl_status = cursor.fetchone()
        if ssl_status and ssl_status[0] == 'on':
            logger.info("SSL connection established successfully")
        else:
            logger.warning("SSL connection status could not be verified")
        
        cursor.close()
        logger.info("Successfully connected to PostgreSQL")
        return conn
        
    except Exception as e:
        logger.error(f"Error connecting to PostgreSQL: {e}")
        raise

def configure_va_user(conn, credentials):
    """Configure VA user with required permissions"""
    cursor = None
    operation_details = []
    start_time = datetime.now()
    
    try:
        cursor = conn.cursor()
        
        # Create or update sqlguard user
        logger.info(f"Creating/updating user {credentials['sqlguard_username']}")
        try:
            # Check if user exists
            check_user_sql = "SELECT 1 FROM pg_catalog.pg_user WHERE usename = %s"
            cursor.execute(check_user_sql, (credentials['sqlguard_username'],))
            user_exists = cursor.fetchone()
            
            if user_exists:
                # Update existing user's password
                alter_user_sql = sql.SQL("ALTER USER {} WITH PASSWORD %s").format(
                    sql.Identifier(credentials['sqlguard_username'])
                )
                cursor.execute(alter_user_sql, (credentials['sqlguard_password'],))
                logger.info(f"Updated password for existing user {credentials['sqlguard_username']}")
            else:
                # Create new user
                create_user_sql = sql.SQL("CREATE USER {} WITH PASSWORD %s").format(
                    sql.Identifier(credentials['sqlguard_username'])
                )
                cursor.execute(create_user_sql, (credentials['sqlguard_password'],))
                logger.info(f"Created new user {credentials['sqlguard_username']}")
            
            operation_details.append({"operation": "create_sqlguard_user", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to create/update user {credentials['sqlguard_username']}: {str(e)}")
            operation_details.append({"operation": "create_sqlguard_user", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant CONNECT on database
        logger.info(f"Granting CONNECT on database {credentials['database']} to {credentials['sqlguard_username']}")
        try:
            grant_connect_sql = sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(
                sql.Identifier(credentials['database']),
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_connect_sql)
            operation_details.append({"operation": "grant_connect", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant CONNECT: {str(e)}")
            operation_details.append({"operation": "grant_connect", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant USAGE on schema public
        logger.info(f"Granting USAGE on schema public to {credentials['sqlguard_username']}")
        try:
            grant_usage_sql = sql.SQL("GRANT USAGE ON SCHEMA public TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_usage_sql)
            operation_details.append({"operation": "grant_usage_schema", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant USAGE on schema: {str(e)}")
            operation_details.append({"operation": "grant_usage_schema", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on all tables in schema public
        logger.info(f"Granting SELECT on all tables in schema public to {credentials['sqlguard_username']}")
        try:
            grant_select_tables_sql = sql.SQL("GRANT SELECT ON ALL TABLES IN SCHEMA public TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_select_tables_sql)
            operation_details.append({"operation": "grant_select_tables", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant SELECT on tables: {str(e)}")
            operation_details.append({"operation": "grant_select_tables", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on all sequences in schema public
        logger.info(f"Granting SELECT on all sequences in schema public to {credentials['sqlguard_username']}")
        try:
            grant_select_sequences_sql = sql.SQL("GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_select_sequences_sql)
            operation_details.append({"operation": "grant_select_sequences", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant SELECT on sequences: {str(e)}")
            operation_details.append({"operation": "grant_select_sequences", "status": "failed", "reason": str(e)})
            raise e
        
        # Alter default privileges for future tables
        logger.info(f"Altering default privileges for future tables to {credentials['sqlguard_username']}")
        try:
            alter_default_sql = sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(alter_default_sql)
            operation_details.append({"operation": "alter_default_privileges", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to alter default privileges: {str(e)}")
            operation_details.append({"operation": "alter_default_privileges", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on pg_catalog system tables
        logger.info(f"Granting SELECT on pg_catalog.pg_user to {credentials['sqlguard_username']}")
        try:
            grant_pg_user_sql = sql.SQL("GRANT SELECT ON pg_catalog.pg_user TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_pg_user_sql)
            
            grant_pg_database_sql = sql.SQL("GRANT SELECT ON pg_catalog.pg_database TO {}").format(
                sql.Identifier(credentials['sqlguard_username'])
            )
            cursor.execute(grant_pg_database_sql)
            operation_details.append({"operation": "grant_pg_catalog_access", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant pg_catalog access: {str(e)}")
            operation_details.append({"operation": "grant_pg_catalog_access", "status": "failed", "reason": str(e)})
            raise e
        
        # Commit all changes
        conn.commit()
        logger.info("All operations committed successfully")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "status": "success",
            "duration_seconds": duration,
            "operations": operation_details
        }
        
    except Exception as e:
        logger.error(f"Error during VA user configuration: {str(e)}")
        logger.info("Attempting to rollback changes")
        try:
            conn.rollback()
            logger.info("Transaction rolled back successfully")
        except Exception as rb_error:
            logger.error(f"Failed to rollback transaction: {rb_error}")
        raise e
    finally:
        if cursor:
            cursor.close()

def main(req: func.HttpRequest) -> func.HttpResponse:
    """Azure Function entry point"""
    logger.info('Azure Function triggered for PostgreSQL VA configuration')
    start_time = datetime.now()
    conn = None
    
    try:
        # Get PostgreSQL credentials from Key Vault
        credentials = get_postgresql_credentials()
        
        # Connect to PostgreSQL
        conn = connect_to_postgresql(credentials)
        
        # Configure VA user and permissions
        result = configure_va_user(conn, credentials)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        response_body = {
            "success": True,
            "message": "VA configuration completed successfully",
            "timestamp": datetime.now().isoformat(),
            "duration_seconds": duration,
            "endpoint": credentials['endpoint'],
            "database": credentials['database'],
            "operations": result["operations"]
        }
        
        return func.HttpResponse(
            json.dumps(response_body, default=str),
            status_code=200,
            mimetype="application/json"
        )
        
    except Exception as e:
        logger.error(f"Function execution failed: {e}")
        
        error_body = {
            "success": False,
            "message": f"Function execution failed: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        
        return func.HttpResponse(
            json.dumps(error_body),
            status_code=500,
            mimetype="application/json"
        )
        
    finally:
        # Always close the connection if it exists
        if conn:
            try:
                conn.close()
                logger.info("Closed PostgreSQL connection")
            except Exception as close_error:
                logger.warning(f"Error closing PostgreSQL connection: {str(close_error)}")

# Made with Bob
