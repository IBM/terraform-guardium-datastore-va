import os
import boto3
import json
import logging
from datetime import datetime
import psycopg2
import psycopg2.sql as sql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
SECRETS_MANAGER_SECRET_ID = os.environ['SECRETS_MANAGER_SECRET_ID']
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
SSL_CA_PATH = '/tmp/global-bundle.pem'

def get_postgres_credentials():
    """Retrieve PostgreSQL credentials from AWS Secrets Manager"""
    try:
        logger.info(f"Retrieving PostgreSQL credentials from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")

        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=AWS_REGION
        )

        # Get the secret value
        get_secret_value_response = client.get_secret_value(
            SecretId=SECRETS_MANAGER_SECRET_ID
        )

        logger.debug(f"Starting credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        # Parse the secret JSON
        secret = json.loads(get_secret_value_response['SecretString'])

        logger.debug(f"Completed credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        logger.info("Successfully retrieved PostgreSQL credentials")

        return {
            'sqlguard_username': secret['sqlguard_username'],
            'sqlguard_password': secret['sqlguard_password'],
            'endpoint': secret['endpoint'],
            'port': secret['port'],
            'username': secret['username'],
            'password': secret['password'],
            'database': secret['database']
        }
    except Exception as e:
        logger.error(f"Error retrieving PostgreSQL credentials: {e}")
        raise

def connect_to_postgres(credentials):
    """Connect to PostgreSQL database"""
    try:
        # Connect to PostgreSQL
        logger.info(f"Connecting to PostgreSQL at {credentials['endpoint']}:{credentials['port']} as {credentials['username']}")
        
        conn = psycopg2.connect(
            host=credentials['endpoint'],
            port=credentials['port'],
            dbname=credentials['database'],
            user=credentials['username'],
            password=credentials['password']
        )
        conn.autocommit = True
        
        logger.info("Successfully connected to PostgreSQL")
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to PostgreSQL: {e}")
        return None

def configure_va_user(conn, credentials):
    """Configure VA user and permissions in PostgreSQL"""
    start_time = datetime.now()
    operation_details = []
    cursor = None
    
    try:
        cursor = conn.cursor()
        
        # Create sqlguard user if it doesn't exist
        logger.info(f"Creating user {credentials['sqlguard_username']} if it doesn't exist")

        username = credentials['sqlguard_username']
        password = credentials['sqlguard_password']
        identifier_username = sql.Identifier(username).as_string(cursor)


        role_exists_query = sql.SQL("SELECT 1 FROM pg_roles WHERE rolname = {user};").format(user=sql.Literal(username))
        cursor.execute(role_exists_query)
        role = cursor.fetchone()
        role_exists = role is not None

        # Create role if it doesn't exist
        if not role_exists:
            logger.info(f"Creating role {username}")
            create_role_sql = sql.SQL(
                "CREATE ROLE {user} LOGIN ENCRYPTED PASSWORD {pwd} NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE;"
            ).format(
                user=sql.Identifier(username),
                pwd=sql.Literal(password)
            )
            cursor.execute(create_role_sql)


        operation_details.append({"operation": "create_sqlguard_user", "status": "success"})

        conn.autocommit = False
        
        # Create gdmmonitor group if it doesn't exist
        logger.info("Creating gdmmonitor group if it doesn't exist")

        sql_create_group = """
        DO $$
        BEGIN
            IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'gdmmonitor') THEN
                CREATE GROUP gdmmonitor;
            END IF;
        END
        $$;
        """
        cursor.execute(sql_create_group)
        
        # Add sqlguard to gdmmonitor group
        logger.info(f"Adding user {credentials['sqlguard_username']} to gdmmonitor group")

        # Use parameterized query to prevent SQL injection
        sql_add_to_group = f"ALTER GROUP gdmmonitor ADD USER {identifier_username};"
        cursor.execute(sql_add_to_group, (credentials['sqlguard_username']))
        operation_details.append({"operation": "add_user_to_group", "status": "success"})
        
        # Grant necessary permissions
        logger.info("Granting necessary permissions")

        sql_grant_permissions = """
        GRANT pg_read_all_settings TO gdmmonitor;
        """
        cursor.execute(sql_grant_permissions)
        operation_details.append({"operation": "grant_permissions", "status": "success"})
        
        # Grant CONNECT privilege to sqlguard
        logger.info(f"Granting CONNECT privilege to {credentials['sqlguard_username']}")
        # Use parameterized query with format() for database name (identifier) and username

        database = credentials['database']
        username = credentials['sqlguard_username']

        sql_grant_connect = sql.SQL("GRANT CONNECT ON DATABASE {db} TO {user};").format(
            db=sql.Identifier(database),
            user=sql.Identifier(username)
        )

        cursor.execute(sql_grant_connect)

        operation_details.append({"operation": "grant_connect", "status": "success"})
        
        # Grant USAGE on schema public to sqlguard
        logger.info(f"Granting USAGE on schema public to {credentials['sqlguard_username']}")


        sql_grant_usage = sql.SQL("GRANT USAGE ON SCHEMA public TO {user};").format(
            user=sql.Identifier(credentials['sqlguard_username'])
        )

        cursor.execute(sql_grant_usage)
        operation_details.append({"operation": "grant_usage", "status": "success"})
        
        # Grant SELECT on all tables in public schema to sqlguard
        logger.info(f"Granting SELECT on all tables in public schema to {credentials['sqlguard_username']}")

        sql_grant_select = sql.SQL("GRANT SELECT ON ALL TABLES IN SCHEMA public TO {user};").format(
            user=sql.Identifier(credentials['sqlguard_username'])
        )

        cursor.execute(sql_grant_select)
        operation_details.append({"operation": "grant_select", "status": "success"})
        
        # Set default privileges for future tables
        logger.info(f"Setting default privileges for future tables for {credentials['sqlguard_username']}")

        sql_default_privileges = sql.SQL(
            "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO {user};"
        ).format(
            user=sql.Identifier(credentials['sqlguard_username'])
        )

        cursor.execute(sql_default_privileges)

        operation_details.append({"operation": "set_default_privileges", "status": "success"})

        # If all operations succeeded, commit the transaction
        conn.commit()
        logger.info("All operations committed successfully")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "status": "success",
            "duration_seconds": duration,
            "operations": operation_details
        }
    except Exception as e:
        logger.error(f"Error configuring VA user: {e}")
        
        # Try to rollback if possible
        try:
            if conn and not conn.closed:
                conn.rollback()
                logger.info("Transaction rolled back")
        except Exception as rollback_err:
            logger.error(f"Error rolling back transaction: {rollback_err}")

        raise e
    finally:
        # Make sure to close the cursor if it's still open
        if cursor:
            try:
                if not cursor.closed:
                    cursor.close()
                    logger.info("Cursor closed")
            except Exception as cursor_err:
                logger.warning(f"Error closing cursor: {cursor_err}")

def handler(event, context):
    """Lambda function entry point"""
    execution_id = context.aws_request_id if context and hasattr(context, 'aws_request_id') else "local-execution"
    logger.info(f"Starting Lambda execution with ID: {execution_id}")
    start_time = datetime.now()
    conn = None
    
    try:
        # Get PostgreSQL credentials from Secrets Manager
        credentials = get_postgres_credentials()
        if credentials is None:
            return {
                "statusCode": 500,
                "body": json.dumps({
                    "success": False,
                    "message": "Failed to retrieve credentials",
                    "timestamp": datetime.now().isoformat(),
                    "execution_id": execution_id
                })
            }
        
        # Connect to PostgreSQL
        conn = connect_to_postgres(credentials)
        if conn is None:
            return {
                "statusCode": 500,
                "body": json.dumps({
                    "success": False,
                    "message": "Failed to connect to PostgreSQL",
                    "timestamp": datetime.now().isoformat(),
                    "execution_id": execution_id
                })
            }
        
        # Configure VA user and permissions
        result = configure_va_user(conn, credentials)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "success": True,
                "message": "VA configuration completed successfully",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "execution_id": execution_id,
                "database": credentials['database'],
                "endpoint": credentials['endpoint'],
            }, default=str)
        }
    except Exception as e:
        logger.error(f"Lambda execution failed: {e}")
        # Close the connection if it exists
        if conn:
            try:
                conn.close()
                logger.info("Closed PostgreSQL connection after error")
            except Exception as close_error:
                logger.warning(f"Error closing PostgreSQL connection: {str(close_error)}")
                
        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "message": f"Lambda execution failed: {str(e)}",
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id
            })
        }
    finally:
        # Always close the connection if it exists
        if conn:
            try:
                conn.close()
                logger.info("Closed PostgreSQL connection")
            except Exception as close_error:
                logger.warning(f"Error closing PostgreSQL connection: {str(close_error)}")

# For local testing
if __name__ == "__main__":
    # Configure basic logging
    logging.basicConfig(level=logging.INFO)
    
    # Set environment variables for local testing
    # Replace these with your own values or load from a local config file
    os.environ['SECRETS_MANAGER_SECRET_ID'] = 'postgres-rds-va-password'
    os.environ['AWS_REGION'] = 'us-east-1'
    
    # NOTE: For security in production, never hardcode credentials
    # These values are for local testing only
    
    # Mock the Secrets Manager client for local testing
    import unittest.mock
    with unittest.mock.patch('boto3.session.Session') as mock_session:
        mock_client = unittest.mock.MagicMock()
        mock_session.return_value.client.return_value = mock_client
        mock_client.get_secret_value.side_effect = [
            {'SecretString': 'admin_password'},
            {'SecretString': 'sqlguard_password'}
        ]
        
        # Call the handler
        try:
            result = handler({}, None)
            print("Result:", result)
            
            # Check if execution was successful
            if result and result.get("statusCode") == 200:
                print("Local test execution successful")
            else:
                print("Local test execution failed")
                if result and "body" in result:
                    try:
                        body = json.loads(result["body"])
                        if "message" in body:
                            print(f"Error message: {body['message']}")
                        if "operations" in body:
                            print("Operations details:")
                            for op in body["operations"]:
                                print(f"  - {op['operation']}: {op['status']}")
                                if op['status'] == 'failed' and 'reason' in op:
                                    print(f"    Reason: {op['reason']}")
                    except json.JSONDecodeError as json_err:
                        print(f"Could not parse response body: {str(json_err)}")
                    except Exception as parse_err:
                        print(f"Error processing response: {str(parse_err)}")
        except Exception as e:
            print(f"Error during local testing: {e}")

