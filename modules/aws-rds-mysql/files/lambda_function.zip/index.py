import os
import boto3
import json
import logging
from datetime import datetime
import pymysql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
SECRETS_MANAGER_SECRET_ID = os.environ['SECRETS_MANAGER_SECRET_ID']
# AWS_REGION is automatically set by Lambda runtime, use SECRETS_REGION for Secrets Manager
SECRETS_REGION = os.environ.get('SECRETS_REGION', os.environ.get('AWS_REGION', 'us-east-1'))

# Required secret keys for validation
REQUIRED_SECRET_KEYS = [
    'sqlguard_username',
    'sqlguard_password',
    'endpoint',
    'port',
    'username',
    'password'
]

def validate_secret_schema(secret):
    """
    Validate that the secret contains all required keys.
    Raises ValueError if validation fails.
    """
    missing_keys = [key for key in REQUIRED_SECRET_KEYS if key not in secret]
    
    if missing_keys:
        error_msg = f"Secret validation failed. Missing required keys: {', '.join(missing_keys)}"
        logger.error(error_msg)
        raise ValueError(error_msg)
    
    # Validate port is numeric
    try:
        int(secret['port'])
    except (ValueError, TypeError) as e:
        error_msg = f"Secret validation failed. 'port' must be a valid integer, got: {secret.get('port')}"
        logger.error(error_msg)
        raise ValueError(error_msg)
    
    logger.info("Secret schema validation passed")
    return True

def get_mysql_credentials():
    """Retrieve MySQL credentials from AWS Secrets Manager"""
    try:
        logger.info(f"Retrieving MySQL credentials from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=SECRETS_REGION
        )
        
        get_secret_value_response = client.get_secret_value(
            SecretId=SECRETS_MANAGER_SECRET_ID
        )
        
        logger.debug(f"Starting credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        secret = json.loads(get_secret_value_response['SecretString'])

        logger.debug(f"Completed credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        
        # Validate secret schema before proceeding
        validate_secret_schema(secret)
        
        logger.info("Successfully retrieved and validated MySQL credentials")
        
        return {
            'sqlguard_username': secret['sqlguard_username'],
            'sqlguard_password': secret['sqlguard_password'],
            'endpoint': secret['endpoint'],
            'port': int(secret['port']),
            'username': secret['username'],
            'password': secret['password']
        }
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing secret JSON: {e}")
        raise ValueError(f"Invalid JSON in secret: {e}")
    except Exception as e:
        logger.error(f"Error retrieving MySQL credentials: {e}")
        raise

def connect_to_mysql(credentials):
    """Connect to MySQL database"""
    try:
        logger.info(f"Connecting to MySQL at {credentials['endpoint']}:{credentials['port']} as {credentials['username']}")
        
        conn = pymysql.connect(
            host=credentials['endpoint'],
            port=credentials['port'],
            user=credentials['username'],
            password=credentials['password'],
            charset='utf8mb4',
            autocommit=False  # Explicitly disable autocommit for transaction control
        )
        
        logger.info("Successfully connected to MySQL")
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to MySQL: {e}")
        raise e

def rollback_va_user(conn, credentials, user_was_created=False):
    """
    Rollback VA user configuration changes.
    
    Args:
        conn: MySQL connection object
        credentials: Dictionary containing sqlguard_username
        user_was_created: Boolean indicating if the user was newly created (vs. password updated)
    """
    try:
        logger.warning("Starting rollback of VA user configuration")
        cursor = conn.cursor()
        
        if user_was_created:
            # If we created the user, drop it
            logger.info(f"Rolling back: Dropping user {credentials['sqlguard_username']}")
            drop_user_sql = f"DROP USER IF EXISTS '{credentials['sqlguard_username']}'@'%'"
            cursor.execute(drop_user_sql)
            logger.info(f"Successfully dropped user {credentials['sqlguard_username']}")
        else:
            # If we only updated the password, we can't easily revert it
            # Log a warning that manual intervention may be needed
            logger.warning(f"User {credentials['sqlguard_username']} existed before this operation. "
                         f"Password was updated but cannot be automatically reverted. "
                         f"Manual intervention may be required.")
        
        conn.commit()
        logger.info("Rollback completed successfully")
        
    except Exception as rollback_error:
        logger.error(f"Error during rollback: {rollback_error}")
        # Don't raise here - we're already in an error state
        try:
            conn.rollback()
        except Exception as rb_error:
            logger.error(f"Failed to rollback transaction: {rb_error}")

def configure_va_user(conn, credentials):
    """Configure VA user and permissions in MySQL"""
    start_time = datetime.now()
    operation_details = []
    cursor = None
    user_was_created = False
    
    try:
        cursor = conn.cursor()
        
        # Create sqlguard user if it doesn't exist
        logger.info(f"Creating/updating user {credentials['sqlguard_username']}")
        try:
            check_user_sql = "SELECT User FROM mysql.user WHERE User = %s"
            cursor.execute(check_user_sql, (credentials['sqlguard_username'],))
            user_exists = cursor.fetchone()
            
            if user_exists:
                alter_user_sql = f"ALTER USER '{credentials['sqlguard_username']}'@'%' IDENTIFIED BY %s"
                cursor.execute(alter_user_sql, (credentials['sqlguard_password'],))
                logger.info(f"Updated password for existing user {credentials['sqlguard_username']}")
                user_was_created = False
            else:
                create_user_sql = f"CREATE USER '{credentials['sqlguard_username']}'@'%' IDENTIFIED BY %s"
                cursor.execute(create_user_sql, (credentials['sqlguard_password'],))
                logger.info(f"Created new user {credentials['sqlguard_username']}")
                user_was_created = True
            
            operation_details.append({"operation": "create_sqlguard_user", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to create/update user {credentials['sqlguard_username']}: {str(e)}")
            operation_details.append({"operation": "create_sqlguard_user", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on mysql.user to sqlguard
        logger.info(f"Granting SELECT on mysql.user to {credentials['sqlguard_username']}")
        try:
            grant_user_sql = f"GRANT SELECT ON mysql.user TO '{credentials['sqlguard_username']}'@'%'"
            cursor.execute(grant_user_sql)
            operation_details.append({"operation": "grant_select_mysql_user", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant SELECT on mysql.user: {str(e)}")
            operation_details.append({"operation": "grant_select_mysql_user", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on mysql.db to sqlguard
        logger.info(f"Granting SELECT on mysql.db to {credentials['sqlguard_username']}")
        try:
            grant_db_sql = f"GRANT SELECT ON mysql.db TO '{credentials['sqlguard_username']}'@'%'"
            cursor.execute(grant_db_sql)
            operation_details.append({"operation": "grant_select_mysql_db", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant SELECT on mysql.db: {str(e)}")
            operation_details.append({"operation": "grant_select_mysql_db", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SHOW DATABASES on *.* to sqlguard
        logger.info(f"Granting SHOW DATABASES on *.* to {credentials['sqlguard_username']}")
        try:
            grant_show_sql = f"GRANT SHOW DATABASES ON *.* TO '{credentials['sqlguard_username']}'@'%'"
            cursor.execute(grant_show_sql)
            operation_details.append({"operation": "grant_show_databases", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to grant SHOW DATABASES: {str(e)}")
            operation_details.append({"operation": "grant_show_databases", "status": "failed", "reason": str(e)})
            raise e
        
        # Apply the privileges
        logger.info("Flushing privileges")
        try:
            cursor.execute("FLUSH PRIVILEGES")
            operation_details.append({"operation": "flush_privileges", "status": "success"})
        except Exception as e:
            logger.error(f"Failed to flush privileges: {str(e)}")
            operation_details.append({"operation": "flush_privileges", "status": "failed", "reason": str(e)})
            raise e
        
        # Commit all changes
        conn.commit()
        logger.info("All operations committed successfully")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "status": "success",
            "duration_seconds": duration,
            "operations": operation_details
        }
        
    except Exception as e:
        logger.error(f"Error during VA user configuration: {str(e)}")
        logger.info("Attempting to rollback changes")
        
        # Attempt rollback
        try:
            conn.rollback()
            logger.info("Transaction rolled back successfully")
        except Exception as rb_error:
            logger.error(f"Failed to rollback transaction: {rb_error}")
        
        # Additional cleanup if user was created
        rollback_va_user(conn, credentials, user_was_created)
        
        # Re-raise the original exception
        raise e
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception as cursor_error:
                logger.warning(f"Error closing cursor: {cursor_error}")

def handler(event, context):
    """Lambda function entry point"""
    execution_id = context.aws_request_id if context and hasattr(context, 'aws_request_id') else "local-execution"
    logger.info(f"Starting Lambda execution with ID: {execution_id}")
    start_time = datetime.now()
    conn = None
    
    try:
        # Get MySQL credentials from Secrets Manager (includes validation)
        credentials = get_mysql_credentials()
        
        # Connect to MySQL
        conn = connect_to_mysql(credentials)
        
        # Configure VA user and permissions
        result = configure_va_user(conn, credentials)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "success": True,
                "message": "VA configuration completed successfully",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "execution_id": execution_id,
                "endpoint": credentials['endpoint'],
                "operations": result["operations"]
            }, default=str)
        }
    except ValueError as ve:
        # Schema validation or parsing errors
        logger.error(f"Validation error: {ve}")
        return {
            "statusCode": 400,
            "body": json.dumps({
                "success": False,
                "message": f"Validation error: {str(ve)}",
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id,
                "error_type": "ValidationError"
            })
        }
    except Exception as e:
        logger.error(f"Lambda execution failed: {e}")
        
        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "message": f"Lambda execution failed: {str(e)}",
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id,
                "error_type": type(e).__name__
            })
        }
    finally:
        if conn:
            try:
                conn.close()
                logger.info("Closed MySQL connection")
            except Exception as close_error:
                logger.warning(f"Error closing MySQL connection: {str(close_error)}")

# For local testing
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    os.environ['SECRETS_MANAGER_SECRET_ID'] = 'mysql-rds-va-password'
    os.environ['SECRETS_REGION'] = 'us-east-1'
    
    import unittest.mock
    with unittest.mock.patch('boto3.session.Session') as mock_session:
        mock_client = unittest.mock.MagicMock()
        mock_session.return_value.client.return_value = mock_client
        mock_client.get_secret_value.return_value = {
            'SecretString': json.dumps({
                'username': 'admin',
                'password': 'admin_password',
                'endpoint': 'localhost',
                'port': '3306',
                'sqlguard_username': 'sqlguard',
                'sqlguard_password': 'sqlguard_password'
            })
        }
        
        try:
            result = handler({}, None)
            print("Result:", result)
            
            if result and result.get("statusCode") == 200:
                print("Local test execution successful")
            else:
                print("Local test execution failed")
                if result and "body" in result:
                    try:
                        body = json.loads(result["body"])
                        if "message" in body:
                            print(f"Error message: {body['message']}")
                        if "operations" in body:
                            print("Operations details:")
                            for op in body["operations"]:
                                print(f"  - {op['operation']}: {op['status']}")
                                if op['status'] == 'failed' and 'reason' in op:
                                    print(f"    Reason: {op['reason']}")
                    except json.JSONDecodeError as json_err:
                        print(f"Could not parse response body: {str(json_err)}")
                    except Exception as parse_err:
                        print(f"Error processing response: {str(parse_err)}")
        except Exception as e:
            print(f"Error during local testing: {e}")

