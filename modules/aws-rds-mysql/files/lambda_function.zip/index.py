import os
import boto3
import json
import logging
from datetime import datetime
import pymysql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
SECRETS_MANAGER_SECRET_ID = os.environ['SECRETS_MANAGER_SECRET_ID']
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
SSL_CA_PATH = '/tmp/global-bundle.pem'

# Required secret keys for validation
REQUIRED_SECRET_KEYS = [
    'sqlguard_username',
    'sqlguard_password',
    'endpoint',
    'port',
    'username',
    'password'
]

def validate_secret_schema(secret):
    """Validate that the secret contains all required keys."""
    missing_keys = [key for key in REQUIRED_SECRET_KEYS if key not in secret]
    if missing_keys:
        error_msg = "Secret validation failed. Missing required keys: {}".format(', '.join(missing_keys))
        logger.error(error_msg)
        raise ValueError(error_msg)
    try:
        int(secret['port'])
    except (ValueError, TypeError) as e:
        error_msg = "Secret validation failed. 'port' must be a valid integer, got: {}".format(secret.get('port'))
        logger.error(error_msg)
        raise ValueError(error_msg)
    logger.info("Secret schema validation passed")
    return True

def get_mysql_credentials():
    """Retrieve MySQL credentials from AWS Secrets Manager"""
    try:
        logger.info("Retrieving MySQL credentials from Secrets Manager: {}".format(SECRETS_MANAGER_SECRET_ID))

        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=AWS_REGION
        )

        # Get the secret value
        get_secret_value_response = client.get_secret_value(
            SecretId=SECRETS_MANAGER_SECRET_ID
        )

        logger.debug("Starting credential request from Secrets Manager: {}".format(SECRETS_MANAGER_SECRET_ID))
        # Parse the secret JSON
        secret = json.loads(get_secret_value_response['SecretString'])

        logger.debug("Completed credential request from Secrets Manager: {}".format(SECRETS_MANAGER_SECRET_ID))
        
        # Validate secret schema before proceeding
        validate_secret_schema(secret)
        
        logger.info("Successfully retrieved and validated MySQL credentials")

        return {
            'sqlguard_username': secret['sqlguard_username'],
            'sqlguard_password': secret['sqlguard_password'],
            'endpoint': secret['endpoint'],
            'port': int(secret['port']),  # Ensure port is an integer
            'username': secret['username'],
            'password': secret['password']
        }
    except Exception as e:
        logger.error("Error retrieving MySQL credentials: {}".format(e))
        raise

def connect_to_mysql(credentials):
    """Connect to MySQL database"""
    try:
        # Connect to MySQL
        logger.info("Connecting to MySQL at {}:{} as {}".format(
            credentials['endpoint'], credentials['port'], credentials['username']))
        
        conn = pymysql.connect(
            host=credentials['endpoint'],
            port=credentials['port'],
            user=credentials['username'],
            password=credentials['password'],
            charset='utf8mb4'
        )
        
        logger.info("Successfully connected to MySQL")
        return conn
    except Exception as e:
        logger.error("Failed to connect to MySQL: {}".format(e))
        raise e

def configure_va_user(conn, credentials):
    """Configure VA user and permissions in MySQL"""
    start_time = datetime.now()
    operation_details = []
    cursor = None
    
    try:
        cursor = conn.cursor()
        
        # Create sqlguard user if it doesn't exist
        logger.info("Creating user {}".format(credentials['sqlguard_username']))
        try:
            # Check if user exists
            check_user_sql = "SELECT User FROM mysql.user WHERE User = %s"
            cursor.execute(check_user_sql, (credentials['sqlguard_username'],))
            user_exists = cursor.fetchone()
            
            if user_exists:
                # Update existing user's password
                create_user_sql = "ALTER USER %s@'%%' IDENTIFIED BY %s"
                cursor.execute(create_user_sql, (credentials['sqlguard_username'], credentials['sqlguard_password']))
                logger.info("Updated password for existing user {}".format(credentials['sqlguard_username']))
            else:
                # Create new user
                create_user_sql = "CREATE USER %s@'%%' IDENTIFIED BY %s"
                cursor.execute(create_user_sql, (credentials['sqlguard_username'], credentials['sqlguard_password']))
                logger.info("Created new user {}".format(credentials['sqlguard_username']))
            
            operation_details.append({"operation": "create_sqlguard_user", "status": "success"})
        except Exception as e:
            logger.error("Failed to create/update user {}: {}".format(credentials['sqlguard_username'], str(e)))
            operation_details.append({"operation": "create_sqlguard_user", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on mysql.user to sqlguard
        logger.info("Granting SELECT on mysql.user to {}".format(credentials['sqlguard_username']))
        try:
            grant_user_sql = "GRANT SELECT ON mysql.user TO %s@'%%'"
            cursor.execute(grant_user_sql, (credentials['sqlguard_username'],))
            operation_details.append({"operation": "grant_select_mysql_user", "status": "success"})
        except Exception as e:
            logger.error("Failed to grant SELECT on mysql.user: {}".format(str(e)))
            operation_details.append({"operation": "grant_select_mysql_user", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SELECT on mysql.db to sqlguard
        logger.info("Granting SELECT on mysql.db to {}".format(credentials['sqlguard_username']))
        try:
            grant_db_sql = "GRANT SELECT ON mysql.db TO %s@'%%'"
            cursor.execute(grant_db_sql, (credentials['sqlguard_username'],))
            operation_details.append({"operation": "grant_select_mysql_db", "status": "success"})
        except Exception as e:
            logger.error("Failed to grant SELECT on mysql.db: {}".format(str(e)))
            operation_details.append({"operation": "grant_select_mysql_db", "status": "failed", "reason": str(e)})
            raise e
        
        # Grant SHOW DATABASES on *.* to sqlguard
        logger.info("Granting SHOW DATABASES on *.* to {}".format(credentials['sqlguard_username']))
        try:
            grant_show_sql = "GRANT SHOW DATABASES ON *.* TO %s@'%%'"
            cursor.execute(grant_show_sql, (credentials['sqlguard_username'],))
            operation_details.append({"operation": "grant_show_databases", "status": "success"})
        except Exception as e:
            logger.error("Failed to grant SHOW DATABASES: {}".format(str(e)))
            operation_details.append({"operation": "grant_show_databases", "status": "failed", "reason": str(e)})
            raise e
        
        # Apply the privileges
        logger.info("Flushing privileges")
        try:
            cursor.execute("FLUSH PRIVILEGES")
            operation_details.append({"operation": "flush_privileges", "status": "success"})
        except Exception as e:
            logger.error("Failed to flush privileges: {}".format(str(e)))
            operation_details.append({"operation": "flush_privileges", "status": "failed", "reason": str(e)})
            raise e
        
        # Commit all changes
        conn.commit()
        logger.info("All operations committed successfully")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "status": "success",
            "duration_seconds": duration,
            "operations": operation_details
        }
        
    except Exception as e:
        logger.error("Error during VA user configuration: {}".format(str(e)))
        logger.info("Attempting to rollback changes")
        try:
            conn.rollback()
            logger.info("Transaction rolled back successfully")
        except Exception as rb_error:
            logger.error("Failed to rollback transaction: {}".format(rb_error))
        raise e
    finally:
        if cursor:
            cursor.close()

def handler(event, context):
    """Lambda function entry point"""
    execution_id = context.aws_request_id if context and hasattr(context, 'aws_request_id') else "local-execution"
    logger.info("Starting Lambda execution with ID: {}".format(execution_id))
    start_time = datetime.now()
    conn = None
    
    try:
        # Get MySQL credentials from Secrets Manager
        credentials = get_mysql_credentials()
        
        # Connect to MySQL
        conn = connect_to_mysql(credentials)
        # Configure VA user and permissions
        result = configure_va_user(conn, credentials)
        
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "success": True,
                "message": "VA configuration completed successfully",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "execution_id": execution_id,
                "endpoint": credentials['endpoint'],
                "operations": result["operations"]
            }, default=str)
        }
    except Exception as e:
        logger.error("Lambda execution failed: {}".format(e))

        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "message": "Lambda execution failed: {}".format(str(e)),
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id
            })
        }
    finally:
        # Always close the connection if it exists
        if conn:
            try:
                conn.close()
                logger.info("Closed MySQL connection")
            except Exception as close_error:
                logger.warning("Error closing MySQL connection: {}".format(str(close_error)))

# For local testing
if __name__ == "__main__":
    # Configure basic logging
    logging.basicConfig(level=logging.INFO)
    
    # Set environment variables for local testing
    # Replace these with your own values or load from a local config file
    os.environ['SECRETS_MANAGER_SECRET_ID'] = 'mysql-rds-va-password'
    os.environ['AWS_REGION'] = 'us-east-1'
    
    # NOTE: For security in production, never hardcode credentials
    # These values are for local testing only
    
    # Mock the Secrets Manager client for local testing
    import unittest.mock
    with unittest.mock.patch('boto3.session.Session') as mock_session:
        mock_client = unittest.mock.MagicMock()
        mock_session.return_value.client.return_value = mock_client
        mock_client.get_secret_value.return_value = {
            'SecretString': json.dumps({
                'username': 'admin',
                'password': 'admin_password',
                'endpoint': 'localhost',
                'port': '3306',
                'sqlguard_password': 'sqlguard_password'
            })
        }
        
        # Call the handler
        try:
            result = handler({}, None)
            print("Result:", result)
            
            # Check if execution was successful
            if result and result.get("statusCode") == 200:
                print("Local test execution successful")
            else:
                print("Local test execution failed")
                if result and "body" in result:
                    try:
                        body = json.loads(result["body"])
                        if "message" in body:
                            print("Error message: {}".format(body['message']))
                        if "operations" in body:
                            print("Operations details:")
                            for op in body["operations"]:
                                print("  - {}: {}".format(op['operation'], op['status']))
                                if op['status'] == 'failed' and 'reason' in op:
                                    print("    Reason: {}".format(op['reason']))
                    except json.JSONDecodeError as json_err:
                        print("Could not parse response body: {}".format(str(json_err)))
                    except Exception as parse_err:
                        print("Error processing response: {}".format(str(parse_err)))
        except Exception as e:
            print("Error during local testing: {}".format(e))

