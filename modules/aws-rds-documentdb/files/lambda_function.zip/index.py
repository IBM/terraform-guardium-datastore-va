#
# Copyright IBM Corp. 2025
# SPDX-License-Identifier: Apache-2.0
#

import os
import json
import logging
import boto3
import pymongo
from datetime import datetime

# Configure logging
logger = logging.getLogger()

if os.getenv("LOG_LEVEL") == "DEBUG":
    logger.info("log level set to DEBUG")
    logger.setLevel(logging.DEBUG)
else:
    logger.info("log level set to INFO")
    logger.setLevel(logging.INFO)

# Get environment variables
SECRETS_MANAGER_SECRET_ID = os.environ['SECRETS_MANAGER_SECRET_ID']
SECRETS_REGION = os.environ['SECRETS_REGION']
SSL_CA_PATH = '/tmp/global-bundle.pem'

def get_documentdb_credentials():
    """Retrieve DocumentDB credentials from AWS Secrets Manager"""
    try:
        logger.info(f"Retrieving DocumentDB credentials from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")

        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=SECRETS_REGION
        )

        # Get the secret value
        get_secret_value_response = client.get_secret_value(
            SecretId=SECRETS_MANAGER_SECRET_ID
        )

        logger.debug(f"Starting credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        # Parse the secret JSON
        secret = json.loads(get_secret_value_response['SecretString'])

        logger.debug(f"Completed credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        logger.info("Successfully retrieved DocumentDB credentials")

        return {
            'sqlguard_username': secret['username'],  # VA user credentials
            'sqlguard_password': secret['password'],
            'endpoint': secret['endpoint'],
            'port': secret['port'],
            'username': secret['admin_username'],  # Admin credentials for creating VA user
            'password': secret['admin_password'],
            'database': secret['database']
        }
    except Exception as e:
        logger.error(f"Error retrieving DocumentDB credentials: {e}")
        raise

def download_certificate():
    """Download the SSL CA certificate for DocumentDB"""
    try:
        # Use urllib to download the certificate
        import urllib.request

        logger.info("Downloading SSL certificate...")

        # Try using urllib first (pure Python solution)
        try:
            urllib.request.urlretrieve("https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem", SSL_CA_PATH)
            logger.info("SSL certificate downloaded successfully using urllib")
        except Exception as e:
            logger.warning(f"urllib download failed: {e}")
            raise e

    except Exception as e:
        logger.error(f"Error downloading SSL certificate: {e}")
        raise

def connect_to_documentdb(credentials):
    """Connect to DocumentDB cluster"""
    try:
        # Connect to DocumentDB using pymongo
        logger.info(f"Connecting to DocumentDB at {credentials['endpoint']}:{credentials['port']} as {credentials['username']}")

        # Get the authentication database (default to 'admin')
        auth_db = credentials.get('database', 'admin')
        
        if os.getenv("TLS", "true").lower() == "false":
            client = pymongo.MongoClient(
                host=credentials['endpoint'],
                port=credentials['port'],
                username=credentials['username'],
                password=credentials['password'],
                authSource=auth_db,
                ssl=False,
            )
        else:
            # Download SSL CA certificate
            download_certificate()
            client = pymongo.MongoClient(
                host=credentials['endpoint'],
                port=credentials['port'],
                username=credentials['username'],
                password=credentials['password'],
                authSource=auth_db,
                ssl=True,
                ssl_ca_certs=SSL_CA_PATH,
            )

        # Test the connection by getting server info
        # This will trigger authentication
        server_info = client.server_info()
        logger.debug(f"Connected to DocumentDB server version: {server_info.get('version', 'unknown')}")

        logger.info("Successfully connected to DocumentDB")
        return {"client": client}
    except Exception as e:
        logger.error(f"Failed to connect to DocumentDB: {e}")
        raise


def roles_are_equal(existing, desired):
    """Compare two roles ignoring order of privileges/actions."""
    def normalize(privileges):
        return sorted([
            {
                "resource": p["resource"],
                "actions": sorted(p["actions"])
            } for p in privileges
        ], key=lambda x: (str(x["resource"]), str(x["actions"])))

    return normalize(existing) == normalize(desired)

def normalize_privileges(privileges):
    """Normalize privilege structure for comparison."""
    return sorted(
        [
            {
                "resource": p["resource"],
            } for p in privileges
        ],
        key=lambda x: (str(x["resource"]), str(x.get("actions", [])))
    )

def user_exists(db, user):
    admin_users = db.command("usersInfo")
    return any(found_user['user'] == user for found_user in admin_users.get('users', []))

def compare_existing_role(db, role_name, desired_privileges):
    logger.info("Checking existing role...")
    roles_info = db.command("rolesInfo", role_name, showPrivileges=True)
    if 'roles' not in roles_info or not roles_info['roles']:
        return False

    existing_role = roles_info['roles']
    existing_privileges = existing_role[0].get("privileges", [])
    if roles_are_equal(existing_privileges, desired_privileges):
        logger.info("roles already in sync, skipping creation")
        return True

    logger.info(f"Replacing role '{role_name}' due to privilege changes...")
    db.command("dropRole", role_name)
    return False

def run_one_time_operation(client, credentials, execution_id="local-execution"):
    """
    Run your one-time operation against DocumentDB
    """
    start_time = datetime.now()
    operation_details = []

    logger.info(f"Running one-time operation on DocumentDB database: {credentials['database']}")
    database = credentials['database']
    # Connect to the admin database
    logger.info(f"Connecting to {database} database...")
    db = client["client"][database]
    operation_details.append({"operation": "connect_to_admin_db", "status": "success"})

    # Create the sqlguard role
    logger.info("Creating sqlguard role...")
    role_creation_command = {
        "createRole": "sqlguard",
        "privileges": [
            {"resource": {"db": "admin", "collection": "system.users"}, "actions": ["find"]},
            {"resource": {"db": "admin", "collection": "system.version"}, "actions": ["find"]}
        ],
        "roles": ["dbOwner"]
    }

    logger.info(role_creation_command)
    if not compare_existing_role(db, "sqlguard", role_creation_command["privileges"]):
        db.command(role_creation_command)
        operation_details.append({"operation": "create_sqlguard_role", "status": "success"})

    if not user_exists(db, credentials['sqlguard_username']):
        # Create a user with the sqlguard role
        logger.info("Creating user with sqlguard role...")
        user_creation_command = {
            "createUser": credentials['sqlguard_username'],
            "pwd": credentials['sqlguard_password'],
            "roles": ["sqlguard"]
        }

        db.command(user_creation_command)
        operation_details.append({"operation": "create_user_with_sqlguard_role", "status": "success"})
        logger.info("role successfully configured")

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "One-time operation completed successfully",
            "timestamp": datetime.now().isoformat(),
            "duration_seconds": duration,
            "operations": operation_details,
            "execution_id": execution_id,
            "database": credentials['database'],
            "endpoint": credentials['endpoint']
        }, default=str)
    }


def lambda_handler(event, context=None):
    """Lambda function entry point"""
    execution_id = context.aws_request_id if context and hasattr(context, 'aws_request_id') else "local-execution"
    logger.info(f"Starting Lambda execution with ID: {execution_id}")

    try:
        # Get DocumentDB credentials from Secrets Manager
        credentials = get_documentdb_credentials()

        # Connect to DocumentDB
        client = connect_to_documentdb(credentials)

        # Run the one-time operation
        res = run_one_time_operation(client, credentials, execution_id)

        # Close the connection
        client["client"].close()
        logger.info("Closed DocumentDB connection")

        return res

    except Exception as e:
        logger.error(f"Lambda execution failed: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "message": f"Lambda execution failed: {str(e)}",
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id
            })
        }

# For local testing
if __name__ == "__main__":
    # Set environment variables for local testing
    os.environ['SECRETS_MANAGER_SECRET_ID'] = 'test-secret-id'
    os.environ['AWS_REGION'] = 'us-east-1'

    # Mock the Secrets Manager client for local testing
    import unittest.mock
    with unittest.mock.patch('boto3.session.Session') as mock_session:
        mock_client = unittest.mock.MagicMock()
        mock_session.return_value.client.return_value = mock_client
        mock_client.get_secret_value.return_value = {
            'SecretString': json.dumps({
                'endpoint': 'localhost',
                'port': 27017,
                'username': 'admin',
                'password': 'password',
                'database': 'admin',
                'sqlguard_username': 'sqlguard',
                'sqlguard_password': 'password'
            })
        }

        # Call the handler
        result = lambda_handler({}, None)
        print(result)

