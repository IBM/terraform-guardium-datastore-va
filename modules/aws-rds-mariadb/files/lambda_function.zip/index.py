import os
import boto3
import json
import logging
from datetime import datetime
import pymysql

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
SECRETS_MANAGER_SECRET_ID = os.environ['SECRETS_MANAGER_SECRET_ID']
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
SSL_CA_PATH = '/tmp/global-bundle.pem'

def get_mariadb_credentials():
    """Retrieve MariaDB credentials from AWS Secrets Manager"""
    try:
        logger.info(f"Retrieving MariaDB credentials from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")

        # Create a Secrets Manager client
        session = boto3.session.Session()
        client = session.client(
            service_name='secretsmanager',
            region_name=AWS_REGION
        )

        # Get the secret value
        get_secret_value_response = client.get_secret_value(
            SecretId=SECRETS_MANAGER_SECRET_ID
        )

        logger.debug(f"Starting credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        # Parse the secret JSON
        secret = json.loads(get_secret_value_response['SecretString'])

        logger.debug(f"Completed credential request from Secrets Manager: {SECRETS_MANAGER_SECRET_ID}")
        logger.info("Successfully retrieved MariaDB credentials")

        return {
            'gdmmonitor_username': secret['gdmmonitor_username'],
            'gdmmonitor_password': secret['gdmmonitor_password'],
            'endpoint': secret['endpoint'],
            'port': int(secret['port']),  # Ensure port is an integer
            'username': secret['username'],
            'password': secret['password']
        }
    except Exception as e:
        logger.error(f"Error retrieving MariaDB credentials: {e}")
        raise

def connect_to_mariadb(credentials):
    """Connect to MariaDB database"""
    try:
        # Connect to MariaDB
        logger.info(f"Connecting to MariaDB at {credentials['endpoint']}:{credentials['port']} as {credentials['username']}")
        
        conn = pymysql.connect(
            host=credentials['endpoint'],
            port=credentials['port'],
            user=credentials['username'],
            password=credentials['password'],
            charset='utf8mb4'
        )
        
        logger.info("Successfully connected to MariaDB")
        return conn
    except Exception as e:
        logger.error(f"Failed to connect to MariaDB: {e}")
        raise e

def configure_va_user(conn, credentials):
    """Configure VA user and permissions in MariaDB"""
    start_time = datetime.now()
    operation_details = []
    cursor = None
    

    cursor = conn.cursor()
    
    # Create gdmmonitor user if it doesn't exist
    logger.info(f"Creating user {credentials['gdmmonitor_username']}")
    try:
        # Check if user exists
        check_user_sql = "SELECT User FROM mysql.user WHERE User = %s"
        cursor.execute(check_user_sql, (credentials['gdmmonitor_username'],))
        user_exists = cursor.fetchone()
        
        if user_exists:
            # Update existing user's password
            create_user_sql = "ALTER USER %s@'%%' IDENTIFIED BY %s"
            cursor.execute(create_user_sql, (credentials['gdmmonitor_username'], credentials['gdmmonitor_password']))
            logger.info(f"Updated password for existing user {credentials['gdmmonitor_username']}")
        else:
            # Create new user
            create_user_sql = "CREATE USER %s@'%%' IDENTIFIED BY %s"
            cursor.execute(create_user_sql, (credentials['gdmmonitor_username'], credentials['gdmmonitor_password']))
            logger.info(f"Created new user {credentials['gdmmonitor_username']}")
        
        operation_details.append({"operation": "create_gdmmonitor_user", "status": "success"})
    except Exception as e:
        logger.error(f"Failed to create/update user {credentials['gdmmonitor_username']}: {str(e)}")
        operation_details.append({"operation": "create_gdmmonitor_user", "status": "failed", "reason": str(e)})
        raise e
    
    # Grant SELECT on mysql.user to gdmmonitor
    logger.info(f"Granting SELECT on mysql.user to {credentials['gdmmonitor_username']}")
    try:
        grant_user_sql = "GRANT SELECT ON mysql.user TO %s@'%%'"
        cursor.execute(grant_user_sql, (credentials['gdmmonitor_username'],))
        operation_details.append({"operation": "grant_select_mysql_user", "status": "success"})
    except Exception as e:
        logger.error(f"Failed to grant SELECT on mysql.user: {str(e)}")
        operation_details.append({"operation": "grant_select_mysql_user", "status": "failed", "reason": str(e)})
        raise e
    
    # Grant SELECT on mysql.db to gdmmonitor
    logger.info(f"Granting SELECT on mysql.db to {credentials['gdmmonitor_username']}")
    try:
        grant_db_sql = "GRANT SELECT ON mysql.db TO %s@'%%'"
        cursor.execute(grant_db_sql, (credentials['gdmmonitor_username'],))
        operation_details.append({"operation": "grant_select_mysql_db", "status": "success"})
    except Exception as e:
        logger.error(f"Failed to grant SELECT on mysql.db: {str(e)}")
        operation_details.append({"operation": "grant_select_mysql_db", "status": "failed", "reason": str(e)})
        raise e
    
    # Grant SHOW DATABASES on *.* to gdmmonitor
    logger.info(f"Granting SHOW DATABASES on *.* to {credentials['gdmmonitor_username']}")
    try:
        grant_show_sql = "GRANT SHOW DATABASES ON *.* TO %s@'%%'"
        cursor.execute(grant_show_sql, (credentials['gdmmonitor_username'],))
        operation_details.append({"operation": "grant_show_databases", "status": "success"})
    except Exception as e:
        logger.error(f"Failed to grant SHOW DATABASES: {str(e)}")
        operation_details.append({"operation": "grant_show_databases", "status": "failed", "reason": str(e)})
        raise e
    
    # Apply the privileges
    logger.info("Flushing privileges")
    try:
        cursor.execute("FLUSH PRIVILEGES")
        operation_details.append({"operation": "flush_privileges", "status": "success"})
    except Exception as e:
        logger.error(f"Failed to flush privileges: {str(e)}")
        operation_details.append({"operation": "flush_privileges", "status": "failed", "reason": str(e)})
        raise e
    
    try:
        # Commit all changes
        conn.commit()
        logger.info("All operations committed successfully")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
    except Exception as e:
        logger.error(f"Failed to commit changes: {str(e)}")
        raise e

    return {
        "status": "success",
        "duration_seconds": duration,
        "operations": operation_details
    }

def handler(event, context):
    """Lambda function entry point"""
    execution_id = context.aws_request_id if context and hasattr(context, 'aws_request_id') else "local-execution"
    logger.info(f"Starting Lambda execution with ID: {execution_id}")
    start_time = datetime.now()
    conn = None
    
    try:
        # Get MariaDB credentials from Secrets Manager
        credentials = get_mariadb_credentials()
        
        # Connect to MariaDB
        conn = connect_to_mariadb(credentials)
        # Configure VA user and permissions
        result = configure_va_user(conn, credentials)
        
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "success": True,
                "message": "VA configuration completed successfully",
                "timestamp": datetime.now().isoformat(),
                "duration_seconds": duration,
                "execution_id": execution_id,
                "endpoint": credentials['endpoint'],
                "operations": result["operations"]
            }, default=str)
        }
    except Exception as e:
        logger.error(f"Lambda execution failed: {e}")

        return {
            "statusCode": 500,
            "body": json.dumps({
                "success": False,
                "message": f"Lambda execution failed: {str(e)}",
                "timestamp": datetime.now().isoformat(),
                "execution_id": execution_id
            })
        }
    finally:
        # Always close the connection if it exists
        if conn:
            try:
                conn.close()
                logger.info("Closed MariaDB connection")
            except Exception as close_error:
                logger.warning(f"Error closing MariaDB connection: {str(close_error)}")

# For local testing
if __name__ == "__main__":
    # Configure basic logging
    logging.basicConfig(level=logging.INFO)
    
    # Set environment variables for local testing
    # Replace these with your own values or load from a local config file
    os.environ['SECRETS_MANAGER_SECRET_ID'] = 'mariadb-rds-va-password'
    os.environ['AWS_REGION'] = 'us-east-1'
    
    # NOTE: For security in production, never hardcode credentials
    # These values are for local testing only
    
    # Mock the Secrets Manager client for local testing
    import unittest.mock
    with unittest.mock.patch('boto3.session.Session') as mock_session:
        mock_client = unittest.mock.MagicMock()
        mock_session.return_value.client.return_value = mock_client
        mock_client.get_secret_value.return_value = {
            'SecretString': json.dumps({
                'username': 'admin',
                'password': 'admin_password',
                'endpoint': 'localhost',
                'port': '3306',
                'gdmmonitor_password': 'gdmmonitor_password'
            })
        }
        
        # Call the handler
        try:
            result = handler({}, None)
            print("Result:", result)
            
            # Check if execution was successful
            if result and result.get("statusCode") == 200:
                print("Local test execution successful")
            else:
                print("Local test execution failed")
                if result and "body" in result:
                    try:
                        body = json.loads(result["body"])
                        if "message" in body:
                            print(f"Error message: {body['message']}")
                        if "operations" in body:
                            print("Operations details:")
                            for op in body["operations"]:
                                print(f"  - {op['operation']}: {op['status']}")
                                if op['status'] == 'failed' and 'reason' in op:
                                    print(f"    Reason: {op['reason']}")
                    except json.JSONDecodeError as json_err:
                        print(f"Could not parse response body: {str(json_err)}")
                    except Exception as parse_err:
                        print(f"Error processing response: {str(parse_err)}")
        except Exception as e:
            print(f"Error during local testing: {e}")

# Made with Bob
